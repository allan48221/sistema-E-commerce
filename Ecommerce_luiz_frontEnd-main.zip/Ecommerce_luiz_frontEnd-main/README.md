Vinicius lozano de Oliveira – 04156102 

Matheus Henrique Estumano Lopes – 04165191 

Marcus Felipe Magalhães Conceição - 04157166 

Fernando Bendelack dos Passos Nicolau – 04162047 

Ayrton Karlos Marques de Sena – 04161809 

João Gabriel Kurosawa Grippa - 04163701
